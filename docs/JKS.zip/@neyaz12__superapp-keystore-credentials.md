# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: ec8d7fbe6165ff4bd1183c20dc29091b
- Android key alias: 703d713a9b2d457a4ac0d5aed5f83f06
- Android key password: 13c5170af2b5a5b3e2fb5669630da2cc
      